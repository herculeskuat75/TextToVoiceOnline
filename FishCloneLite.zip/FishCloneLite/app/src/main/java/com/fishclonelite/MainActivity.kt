package com.fishclonelite

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class MainActivity : AppCompatActivity() {

    lateinit var selectedWavBase64: String
    private var lastSavedUri: Uri? = null

    private val pickWav = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) handleWavUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnPickRef).setOnClickListener {
            pickWav.launch(arrayOf("audio/wav", "audio/x-wav"))
        }
        findViewById<Button>(R.id.btnGenerate).setOnClickListener {
            val etApiKey = findViewById<EditText>(R.id.etApiKey)
            val etText = findViewById<EditText>(R.id.etText)
            val etRef = findViewById<EditText>(R.id.etRefTranscript)
            val progressBar = findViewById<View>(R.id.progressBar)
            val btnGenerate = findViewById<Button>(R.id.btnGenerate)
            val btnPlay = findViewById<Button>(R.id.btnPlay)

            val apiKey = etApiKey.text.toString().trim()
            if (apiKey.isEmpty()) {
                Toast.makeText(this, "API Key tidak boleh kosong", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!::selectedWavBase64.isInitialized || selectedWavBase64.isEmpty()) {
                Toast.makeText(this, "Pilih audio WAV referensi dulu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (etRef.text.isNullOrBlank()) {
                Toast.makeText(this, "Isi transkrip referensi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (etText.text.isNullOrBlank()) {
                Toast.makeText(this, "Isi teks yang akan dibacakan", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (etText.length() > 500) {
                Toast.makeText(this, "Teks maksimal 500 karakter", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            progressBar.visibility = View.VISIBLE
            btnGenerate.isEnabled = false

            val text = etText.text.toString()
            val refText = etRef.text.toString()
            val wavBase64 = selectedWavBase64

            CoroutineScope(Dispatchers.IO).launch {
                var pendingUri: Uri? = null
                try {
                    val packed = MsgPackUtils.packTtsRequest(
                        text = text,
                        format = "mp3",
                        references = listOf(FishReference(audio = wavBase64, text = refText))
                    )
                    val requestBody = packed.toRequestBody(MsgPackUtils.CONTENT_TYPE.toMediaType())
                    val response = ApiClient.service.generateTts(
                        "Bearer $apiKey", "s2.1-pro-free", MsgPackUtils.CONTENT_TYPE, requestBody
                    )
                    if (!response.isSuccessful) {
                        val code = response.code()
                        response.errorBody()?.close()
                        throw IllegalStateException(
                            when (code) {
                                401 -> "HTTP 401: API key tidak valid"
                                402 -> "HTTP 402: Saldo/kuota tidak cukup"
                                429 -> "HTTP 429: Terlalu banyak permintaan"
                                503 -> "HTTP 503: Layanan sedang tidak tersedia"
                                else -> "HTTP $code: Gagal generate"
                            }
                        )
                    }
                    val body = response.body() ?: throw IllegalStateException("Respons kosong")

                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, "fish_tts_${System.currentTimeMillis()}.mp3")
                        put(MediaStore.Downloads.MIME_TYPE, "audio/mpeg")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(MediaStore.Downloads.IS_PENDING, 1)
                        }
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Gagal membuat file di Downloads")
                    pendingUri = uri

                    body.byteStream().use { input ->
                        contentResolver.openOutputStream(uri)?.use { out -> input.copyTo(out) }
                            ?: throw IllegalStateException("Gagal menulis file MP3")
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                        contentResolver.update(uri, done, null, null)
                    }
                    pendingUri = null
                    lastSavedUri = uri

                    withContext(Dispatchers.Main) {
                        progressBar.visibility = View.GONE
                        btnGenerate.isEnabled = true
                        btnPlay.isEnabled = true
                        Toast.makeText(this@MainActivity, "MP3 tersimpan di Downloads", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    pendingUri?.let { runCatching { contentResolver.delete(it, null, null) } }
                    withContext(Dispatchers.Main) {
                        progressBar.visibility = View.GONE
                        btnGenerate.isEnabled = true
                        Toast.makeText(
                            this@MainActivity,
                            e.message ?: "Terjadi kesalahan",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }
        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            val uri = lastSavedUri
            if (uri == null) {
                Toast.makeText(this, "Belum ada file MP3", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "audio/mpeg")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            } catch (e: Exception) {
                Toast.makeText(this, "Tidak ada aplikasi pemutar musik", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleWavUri(uri: Uri) {
        try {
            val name = queryDisplayName(uri) ?: "reference.wav"
            val cacheFile = File(cacheDir, "ref_audio.wav")
            contentResolver.openInputStream(uri)?.use { input ->
                cacheFile.outputStream().use { out -> input.copyTo(out) }
            } ?: throw IllegalArgumentException("Tidak dapat membuka file")

            selectedWavBase64 = cacheFile.inputStream().use { WavUtils.parseWavToBase64(it) }
            findViewById<TextView>(R.id.tvRefName).text = name
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "Gagal membaca WAV", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryDisplayName(uri: Uri): String? =
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
}
