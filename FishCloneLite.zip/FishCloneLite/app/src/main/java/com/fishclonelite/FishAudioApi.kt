package com.fishclonelite

import android.util.Base64
import okhttp3.RequestBody
import okhttp3.ResponseBody
import org.msgpack.core.MessagePack
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

/** audio = base64 string WAV (dari WavUtils); akan dikirim sebagai binary di MessagePack. */
data class FishReference(val audio: String, val text: String)

interface FishAudioService {
    @POST("v1/tts")
    suspend fun generateTts(
        @Header("Authorization") auth: String,
        @Header("model") model: String,
        @Header("Content-Type") contentType: String,
        @Body requestBody: RequestBody
    ): Response<ResponseBody>
}

object MsgPackUtils {
    const val CONTENT_TYPE = "application/msgpack"

    /** Pack (text, format, references) menjadi byte array MessagePack. */
    fun packTtsRequest(text: String, format: String, references: List<FishReference>?): ByteArray {
        val packer = MessagePack.newDefaultBufferPacker()
        packer.use { p ->
            val fieldCount = if (references.isNullOrEmpty()) 2 else 3
            p.packMapHeader(fieldCount)

            p.packString("text")
            p.packString(text)

            p.packString("format")
            p.packString(format)

            if (!references.isNullOrEmpty()) {
                p.packString("references")
                p.packArrayHeader(references.size)
                for (ref in references) {
                    p.packMapHeader(2)
                    p.packString("audio")
                    val audioBytes = Base64.decode(ref.audio, Base64.DEFAULT)
                    p.packBinaryHeader(audioBytes.size)
                    p.writePayload(audioBytes)
                    p.packString("text")
                    p.packString(ref.text)
                }
            }
            return p.toByteArray()
        }
    }
}

object ApiClient {
    val service: FishAudioService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.fish.audio/")
            .build()
            .create(FishAudioService::class.java)
    }
}
