package com.fishclonelite

import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST

data class FishReference(val audio: String, val text: String)

data class FishTtsRequest(
    val text: String,
    val format: String,
    val references: List<FishReference>?
)

interface FishAudioService {
    @POST("v1/tts")
    @Headers("Content-Type: application/json")
    suspend fun generateTts(
        @Header("Authorization") auth: String,
        @Header("model") model: String,
        @Body request: FishTtsRequest
    ): Response<ResponseBody>
}

object ApiClient {
    val service: FishAudioService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.fish.audio/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(FishAudioService::class.java)
    }
}
