package com.fishclonelite

import android.util.Base64
import java.io.InputStream

object WavUtils {

    fun parseWavToBase64(input: InputStream): String {
        val bytes = input.readBytes()
        if (bytes.size < 12) throw IllegalArgumentException("File terlalu kecil, bukan WAV valid")
        if (tag(bytes, 0) != "RIFF" || tag(bytes, 8) != "WAVE") {
            throw IllegalArgumentException("Bukan file WAV (header RIFF/WAVE tidak ditemukan)")
        }

        var pos = 12
        var sampleRate = 0
        var numChannels = 0
        var bitsPerSample = 0
        var fmtFound = false
        var dataOffset = -1
        var dataLength = 0

        while (pos + 8 <= bytes.size) {
            val id = tag(bytes, pos)
            val size = le32(bytes, pos + 4)
            val body = pos + 8

            if (id == "fmt ") {
                if (size < 16 || body + 16 > bytes.size) {
                    throw IllegalArgumentException("Chunk 'fmt ' rusak")
                }
                val audioFormat = le16(bytes, body)
                numChannels = le16(bytes, body + 2)
                sampleRate = le32(bytes, body + 4)
                bitsPerSample = le16(bytes, body + 14)
                if (audioFormat != 1 && audioFormat != 0xFFFE) {
                    throw IllegalArgumentException("Format audio WAV tidak didukung (hanya PCM)")
                }
                fmtFound = true
            } else if (id == "data") {
                dataOffset = body
                val remaining = bytes.size - body
                dataLength = if (size < 0 || size > remaining) remaining else size
                break
            }

            if (size < 0) break
            pos = body + size + (size and 1)
        }

        if (!fmtFound) throw IllegalArgumentException("Chunk 'fmt ' tidak ditemukan")
        if (dataOffset < 0) throw IllegalArgumentException("Chunk 'data' tidak ditemukan")
        if (bitsPerSample != 16) {
            throw IllegalArgumentException(
                "Hanya WAV PCM 16-bit yang didukung, file ini $bitsPerSample-bit"
            )
        }
        if (numChannels < 1 || sampleRate <= 0) {
            throw IllegalArgumentException("Header WAV tidak valid (channel/sample rate)")
        }
        if (dataLength <= 0) throw IllegalArgumentException("Data audio WAV kosong")

        return Base64.encodeToString(bytes, dataOffset, dataLength, Base64.NO_WRAP)
    }

    private fun tag(b: ByteArray, o: Int): String = String(b, o, 4, Charsets.ISO_8859_1)

    private fun le16(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun le32(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or
            ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or
            ((b[o + 3].toInt() and 0xFF) shl 24)
}
